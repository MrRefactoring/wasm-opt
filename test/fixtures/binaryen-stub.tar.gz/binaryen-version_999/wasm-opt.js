#!/usr/bin/env node
console.log("wasm-opt version 999");
